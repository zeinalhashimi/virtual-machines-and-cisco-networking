print("🐳 Hello from Docker!")
print("This Python app is running inside a container.")
print("No matter where Docker runs, this output is the same.")
